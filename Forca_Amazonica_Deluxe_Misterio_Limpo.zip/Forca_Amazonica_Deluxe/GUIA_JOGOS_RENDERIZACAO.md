# Guia de interface e renderização de jogos em Python (Forca Amazônica)

## 1. Quatro partes de um jogo básico

- **Motor (`motor_grafico.py`)**: decide acertos, erros, vitória e placar.
- **Persistência (`motor_grafico.py`)**: serializa o estado em JSON e o recupera.
- **Recursos (`assets/`)**: imagens PNG, GIFs, efeitos WAV, trilha e ícone.
- **Interface (`forca_pygame.py`)**: organiza painéis, desenha imagens e responde a eventos.

A vantagem dessa divisão: é possível trocar totalmente a aparência do jogo e manter a lógica intacta.

## 2. Como funciona o *game loop*

```text
INICIALIZAR JANELA → CARREGAR JOGO E RECURSOS
         ↓
┌──────────────────────────────────────────────┐
│ CAPTAR EVENTOS (teclas e cliques)            │
│ MUDAR ESTADO (acertos, erros, avançar fase)  │
│ SALVAR ESTADO se houve mudança importante    │
│ ATUALIZAR GIF (selecionar quadro pelo tempo) │
│ DESENHAR o cenário, a imagem e os botões     │
│ APRESENTAR A TELA (display.flip)             │
│ LIMITAR A TAXA (clock.tick(30))              │
└───────────────────────┬──────────────────────┘
                        └── repetir até sair
```

`FPS = 30` é uma escolha econômica para um jogo de perguntas e palavras em um notebook modesto. Em jogos de movimento rápido, 60 FPS pode ser mais agradável se o hardware suportar.

## 3. PNG, GIF, sprites e animações

- **PNG**: imagem estática, normalmente com suporte a transparência.
- **GIF**: sequência de quadros com durações; o Pygame não cria automaticamente uma animação com `image.load` — este jogo usa Pillow para ler os quadros e reproduzi-los no tempo certo.
- **Sprite**: elemento visual reutilizável, geralmente com posição, imagem e estado.
- **Animação procedural**: movimento calculado matematicamente, por exemplo um peixe subindo e descendo suavemente; não é obrigatório usar um GIF para animar.

Este pacote mostra ilustrações próprias de nove palavras. Você pode adicionar fotos/GIFs de espécies usando a pasta `%APPDATA%\ForcaAmazonica\imagens`; escolha os nomes com base na tupla `PALAVRAS`.

## 4. Sons e músicas

No Pygame existem dois usos comuns:

```python
pygame.mixer.Sound('assets/sons/clique.wav').play()  # efeito curto
pygame.mixer.music.load('assets/sons/floresta_ambiente.wav')
pygame.mixer.music.play(-1)                           # música em loop
```

O código principal também guarda as preferências de áudio em JSON, de modo que o jogador não precise desligar a música sempre que abrir o jogo. Os WAVs incluídos são sintetizados para este projeto, evitando usar músicas comerciais sem licença.

## 5. Recomendações de design visual

**Hierarquia:** o jogador primeiro precisa enxergar a dica e a palavra, depois as vidas e o teclado. O placar e a ilustração são secundários.

**Consistência:** botões com a mesma altura, espaçamento regular e cores semânticas: verde para ações/acerto, vermelho para derrota, cinza para desabilitado.

**Acessibilidade:** texto com contraste suficiente, operação por teclado e mouse, sons com opção de desligar, fontes legíveis.

**Performance:** carregue imagens somente quando a palavra muda; desenhe o fundo uma vez; não leia JSON a cada frame. Este código grava o JSON a cada tentativa, e não 30 vezes por segundo.

## 6. Como o salvamento funciona

```python
# Exemplo simplificado
estado = {
    'rodada': 1,
    'acertadas': ['t', 'a'],
    'erradas': ['x'],
    'vidas': 5,
    'pontuacao': 0
}
```

O código real tem mais campos e validação. A função `salvar_jogo()` usa `json.dump()` para gravar e `os.replace()` para trocar o arquivo temporário pelo definitivo. O JSON vai para a pasta de dados do usuário e não para dentro do EXE.

## 7. O que é um .exe e por que criar no Windows?

O **PyInstaller** lê seu script e o empacota com o interpretador Python, bibliotecas e arquivos de dados. Com `--onefile`, gera um executável único para a plataforma usada durante o empacotamento; não é um tradutor do Python para C nem um instalador de celular.

Para Windows, use o `GERAR_EXECUTAVEL_WINDOWS.bat`. Ele contém o comando `python -m PyInstaller --onefile --windowed ... --add-data "assets;assets"`. O jogo encontra esses recursos ao executar o pacote e mantém saves na pasta APPDATA, fora da área temporária do executável.

## 8. Sua próxima experiência de laboratório

1. Faça uma rodada, feche e confira o JSON em `%APPDATA%\ForcaAmazonica`.
2. Desligue a música, feche e reabra; confira se a preferência foi mantida.
3. Coloque uma imagem sua chamada `jaraqui.png` na pasta `imagens` e chegue à palavra `jaraqui`.
4. Compare o tempo do jogo em `FPS = 30` e `FPS = 60` e avalie o uso de CPU.
5. Gere seu executável no Windows; compare execução do `.py` e do `.exe`.
