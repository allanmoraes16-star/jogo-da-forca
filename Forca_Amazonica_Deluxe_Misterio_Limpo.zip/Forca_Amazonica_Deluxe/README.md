**Ajuste visual:** antes da descoberta, aparece só o **?** com **MISTÉRIO AMAZÔNICO** vibrando em cores, sem as antigas mensagens explicativas.

# 🌿 Forca Amazônica — Edição Deluxe (Projeto 08 / CETAM)

Uma evolução didática do **Projeto 08 — Jogo da Forca Amazônica**: **96 palavras** (32 peixes, 32 frutas/sementes, 32 outros animais), dicas, teclado na tela, progresso persistente, música de fundo, efeitos sonoros e ilustrações animadas.

**Importante:** este é um **jogo de computador para Windows**, não um APK Android. O arquivo `.exe` é produzido no próprio Windows com o gerador incluído. O código do exercício do CETAM (`projeto08_forca.py`) foi preservado e roda no terminal sem depender de Pygame.

## 1. Como abrir o jogo no VS Code

1. Extraia completamente o ZIP e abra a pasta `Forca_Amazonica_Deluxe` no VS Code.
2. No terminal integrado (`Ctrl + J`), execute:

   ```powershell
   python -m pip install --only-binary=:all: pygame-ce pillow
   ```

   - `pygame-ce`: cria a janela, desenha os botões e reproduz os sons.
   - `pillow`: lê os quadros dos **GIFs animados**; sem Pillow, a arte PNG de reserva é usada.
   - **Não** é suficiente instalar uma extensão do VS Code; são pacotes Python.

3. Abra o jogo:

   ```powershell
   python forca_pygame.py
   ```

   Se o VS Code tiver múltiplos Pythons, use **Ctrl + Shift + P → Python: Select Interpreter** e escolha o Python em que instalou os pacotes.

## 2. Como funciona o salvamento automático

O jogo salva **a cada letra inédita**, **depois de uma rodada**, **ao trocar música ou efeitos** e **quando você fecha a janela**. Também há um botão **SALVAR** e a tecla `F5`.

Salva exatamente:
- número da rodada e palavra atual;
- letras acertadas e erradas;
- vidas restantes e estado de vitória/derrota;
- vitórias e pontuação acumulada;
- preferência de música e efeitos ligados/desligados.

Ao abrir novamente, recupera a partida automaticamente. A escrita utiliza arquivo temporário e substituição atômica para reduzir o risco de perda em encerramentos inesperados.

**Local do arquivo no Windows:**

```text
%APPDATA%\ForcaAmazonica\progresso.json
```

**Como localizar:** pressione `Win + R`, cole `%APPDATA%\ForcaAmazonica` e pressione `Enter`. **O arquivo NÃO fica dentro do `.exe` ou da pasta que você extraiu.** Ele permanece no perfil do usuário, mesmo que você atualize ou mova o executável.

> O salvamento automático é da **versão gráfica Deluxe**. O jogo de terminal original continua independente e não compartilha o progresso. Um backup manual do `progresso.json` é recomendado antes de trocar o banco de palavras.

### Teste prático do salvamento

1. Abra a versão gráfica e escolha as letras `T`, `A` e `X`.
2. Feche com `Esc` ou no `X` da janela.
3. Execute `python forca_pygame.py` de novo.
4. A partida deve voltar com as letras e vidas de antes, na mesma rodada.
5. Confirme que o arquivo `progresso.json` existe.

Se o JSON for editado incorretamente, o jogo inicia uma nova partida e avisa que não foi possível recuperar o progresso. Ele **não apaga propositalmente o arquivo inválido**; guarde-o para diagnóstico.

## 3. Controles

| Ação | Tecla / controle |
|---|---|
| Adivinhar | Digite uma letra de A a Z ou clique no teclado virtual |
| Continuar após vitória/derrota | `Enter` ou botão **PRÓXIMA RODADA** |
| Salvar manualmente | `F5` ou botão **SALVAR** |
| Reiniciar o jogo | `F6` ou **NOVO JOGO**, depois `Enter` para confirmar |
| Cancelar reinício | `Esc` durante a confirmação |
| Ligar/desligar música | `F8` ou botão **MÚSICA** |
| Ligar/desligar efeitos | `F9` ou botão **SONS** |
| Sair e salvar | `Esc` ou fechar a janela |

**Atenção:** criar **NOVO JOGO** substitui o progresso anterior após confirmação. Para guardar dois perfis, faça backup manual do JSON antes; esta versão possui **um único slot de salvamento**.

## 4. Músicas, botões e GIFs

Em `assets/sons/`, o pacote possui arquivos WAV **originais, sintetizados para este projeto**:

- `floresta_ambiente.wav`: uma trilha instrumental/ambiente em repetição;
- `clique.wav`, `acerto.wav`, `erro.wav`, `vitoria.wav`: efeitos de interface e jogo.

Em `assets/gifs/`, há **9 GIFs animados curtos** com movimentos suaves (8 quadros por animação). Em `assets/ilustracoes/`, estão as respectivas **9 ilustrações PNG** para fallback. Os temas ilustrados são: tambaqui, pirarucu, tucunaré, cupuaçu, açaí, tucumã, onça, ariranha e boto. Essas imagens são **ilustrações artísticas, não fotografias de referência científica**.

Para as outras 87 palavras, aparece uma **imagem temática da categoria**, identificada como tal; isso evita afirmar que uma imagem de tambaqui é a foto exata de outra espécie. A aplicação não inclui fotos reais de cada uma das 96 palavras.

### Como colocar imagens/GIFs de TODAS as 96 palavras

Você pode adicionar sua própria imagem de cada espécie ou fruto, nomeando o arquivo igual à resposta (minúsculo, sem espaços e acentos):

```text
%APPDATA%\ForcaAmazonica\imagens\jaraqui.png
%APPDATA%\ForcaAmazonica\imagens\arara.gif
%APPDATA%\ForcaAmazonica\imagens\cupui.jpg
```

O jogo automaticamente prefere essas imagens personalizadas, sem alterar o código. São aceitos **`.gif`, `.png`, `.jpg`, `.jpeg`, `.webp`**, desde que o sistema disponha de um leitor de imagem compatível. Para GIF animado é necessário Pillow. GIFs muito longos são limitados aos primeiros 60 quadros para economizar memória.

**Direitos de imagem:** use imagens autorais, licenciadas para reutilização ou de domínio público. Não copie GIFs aleatórios da internet para distribuir dentro de um jogo sem verificar a licença.

## 5. Como gerar seu arquivo final `.exe` no Windows

**O `.exe` deve ser compilado no Windows.** O pacote não contém um executável pronto; inclui um gerador `.bat` para o seu computador. A ferramenta usada é o PyInstaller.

### Opção fácil: dois cliques

Na pasta que você extraiu, dê dois cliques em:

```text
GERAR_EXECUTAVEL_WINDOWS.bat
```

Ele verifica o Python, instala as bibliotecas e executa o empacotamento do jogo com músicas, GIFs, imagens e ícone incluídos.

Ao terminar com sucesso, o resultado estará em:

```text
dist\ForcaAmazonica.exe
```

**Esse executável poderá abrir sem VS Code e sem instalar Python no computador de destino**, desde que seja um Windows compatível. O empacotador inclui o interpretador e as dependências. O `.exe` pode demorar um pouco mais para iniciar na primeira vez porque o modo `--onefile` extrai recursos temporários.

### Opção manual: comandos no terminal do VS Code

```powershell
python -m pip install --only-binary=:all: pygame-ce pillow pyinstaller
python -m PyInstaller --noconfirm --clean --onefile --windowed --name ForcaAmazonica --icon "assets\icone.ico" --add-data "assets;assets" --hidden-import PIL.GifImagePlugin forca_pygame.py
```

- `--onefile`: tenta produzir **um único `.exe`**.
- `--windowed`: inicia sem uma janela extra de terminal.
- `--add-data "assets;assets"`: inclui música, imagens e GIFs no pacote Windows.
- `--icon`: adiciona o ícone do jogo.
- `--hidden-import`: assegura que o suporte à leitura de GIF seja incluído.

**Atenção:** para criar um instalador tradicional (como `.msi` ou assistente "Próximo, Próximo, Concluir"), há uma etapa adicional com ferramenta de instalação. Este pacote gera **um aplicativo portátil `.exe`**, não um instalador do Windows.

Se o `.exe` não abrir, remova temporariamente `--windowed` do comando e gere novamente para enxergar a mensagem de erro no console; execute o arquivo gerado no seu próprio Windows primeiro.

## 6. Organização do projeto

```text
Forca_Amazonica_Deluxe/
├── projeto08_forca.py       # Exercício original do CETAM, 96 palavras (terminal)
├── motor_grafico.py         # Regras compartilháveis + salvar/carregar JSON
├── forca_pygame.py         # Interface, cliques, música, GIFs, game loop
├── criar_recursos.py        # Opcional: regenera sons e GIFs originais
├── atlas_arte.png          # Fonte das 9 ilustrações originais
├── GERAR_EXECUTAVEL_WINDOWS.bat
├── requirements.txt
├── README.md
├── GUIA_JOGOS_RENDERIZACAO.md
├── assets/
│   ├── icone.ico
│   ├── gifs/               # 9 GIFs animados
│   ├── ilustracoes/        # 9 PNGs estáticos
│   └── sons/               # 1 música + 4 efeitos WAV
└── testes/
    └── test_motor_grafico.py
```

## 7. Testes e limitações

No terminal execute:

```powershell
python -m unittest discover -s testes -v
```

O motor Python passou por **11 testes automáticos**, inclusive fechar/reabrir o JSON no meio de uma rodada, vitória com 40 pontos, derrota, letras repetidas, continuidade, validação de dados e proteção contra sobrescrever um save válido com um estado inválido.

**Limite de validação:** neste ambiente foi possível gerar os recursos, compilar sintaticamente os `.py` e testar a lógica sem Pygame, mas **não executar uma janela Pygame nem compilar e testar o `.exe` de Windows**. O programa gráfico e a geração do executável devem ser testados no seu computador.

## 8. Próximas melhorias sugeridas

1. **Banco de imagens completo:** usar imagens licenciadas ou autorais para as 96 palavras, em vez de 9 figuras ilustrativas e categorias temáticas.
2. **Seleção de categorias e dificuldade:** peixes/frutas/animais, vidas ajustáveis e palavras de diferentes comprimentos.
3. **Perfis e conquistas:** múltiplos slots, ranking local, medalhas por descobertas, revisão das palavras erradas.
4. **Glossário educativo:** mostrar foto, nome científico, distribuição geográfica e áudio pronunciando a palavra após acertar.
5. **Revisão de publicação:** testes em Windows limpo, acessibilidade de fontes, volumes e tela, escaneamento de arquivos de terceiros, licenças e ícone.

O arquivo `GUIA_JOGOS_RENDERIZACAO.md` explica como evoluir a interface sem misturar gráficos com a lógica do jogo.
