@echo off
setlocal
cd /d "%~dp0"
title Forca Amazonica - Criar EXE

echo =======================================================
echo    FORCA AMAZONICA DELUXE - GERADOR DO EXECUTAVEL
 echo =======================================================
echo.
echo Este arquivo instala as dependencias e compila o jogo.
echo Execute no WINDOWS, nao no celular.
echo.
python --version
if errorlevel 1 (
    echo Python nao encontrado. Instale Python ou corrija PATH.
    pause
    exit /b 1
)

echo.
echo [1/3] Instalando dependencias para o Python selecionado...
python -m pip install --only-binary=:all: pygame-ce pillow pyinstaller
if errorlevel 1 (
    echo Falha na instalacao. Verifique sua internet e a versao do Python.
    pause
    exit /b 1
)

echo.
echo [2/3] Gerando ForcaAmazonica.exe (pode demorar)...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name ForcaAmazonica --icon "assets\icone.ico" --add-data "assets;assets" --hidden-import PIL.GifImagePlugin forca_pygame.py
if errorlevel 1 (
    echo O empacotamento falhou. Veja o erro acima.
    pause
    exit /b 1
)

echo.
echo [3/3] PRONTO!
echo Executavel: %~dp0dist\ForcaAmazonica.exe
if exist "dist\ForcaAmazonica.exe" explorer "dist"
echo Seu progresso fica salvo no APPDATA, mesmo mudando o EXE de lugar.
pause
