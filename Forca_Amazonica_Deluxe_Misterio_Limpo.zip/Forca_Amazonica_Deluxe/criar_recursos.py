"""Regenera sons originais e GIFs a partir das ilustrações PNG incluídas.
A execução do jogo NÃO depende deste script (os assets já estão prontos).
Requer Pillow somente para a regeneração dos GIFs.
"""
from pathlib import Path
from PIL import Image, ImageDraw
import math
import wave
import struct
import random

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'assets'
ORIGEM = Path(__file__).resolve().parent / 'atlas_arte.png'
NOMES = ['tambaqui','pirarucu','tucunare','cupuacu','acai','tucuma','onca','ariranha','boto']

def criar_gifs():
    if ORIGEM.exists():
        atlas=Image.open(ORIGEM).convert('RGB')
        w,h=atlas.size
        for i,nome in enumerate(NOMES):
            c,r=i%3,i//3
            x1=round(c*w/3)+6; y1=round(r*h/3)+6
            x2=round((c+1)*w/3)-6; y2=round((r+1)*h/3)-6
            foto=atlas.crop((x1,y1,x2,y2)).resize((310,310),Image.Resampling.LANCZOS)
            foto.save(ASSETS/'ilustracoes'/f'{nome}.png', optimize=True)
    for i,nome in enumerate(NOMES):
        arquivo=ASSETS/'ilustracoes'/f'{nome}.png'
        if not arquivo.exists(): continue
        fonte=Image.open(arquivo).convert('RGB').resize((306,306))
        quadros=[]
        for frame in range(8):
            deslocamento=int(round(3*math.sin(2*math.pi*frame/8)))
            zoom=1.01 + 0.009*math.sin(2*math.pi*frame/8)
            tamanho=int(306*zoom)
            maior=fonte.resize((tamanho,tamanho),Image.Resampling.BICUBIC)
            x=(tamanho-306)//2
            base=maior.crop((x,x,306+x,306+x))
            if deslocamento:
                tela=Image.new('RGB',(306,306),(18,67,46))
                tela.paste(base,(0,deslocamento))
                if deslocamento>0:
                    tela.paste(base.crop((0,0,306,deslocamento)),(0,0))
                else:
                    tela.paste(base.crop((0,306+deslocamento,306,306)),(0,306+deslocamento))
                base=tela
            d=ImageDraw.Draw(base,'RGBA')
            # pontos de luz sutis e originais para demonstrar animação em GIF
            for n in range(4):
                xx=(30+n*69+frame*5+i*11)%290+5
                yy=(22+n*61-frame*4+i*9)%275+10
                rr=1+(n%2)
                d.ellipse((xx-rr,yy-rr,xx+rr,yy+rr),fill=(255,250,186,110))
            quadros.append(base.quantize(colors=128))
        quadros[0].save(ASSETS/'gifs'/f'{nome}.gif', save_all=True,
                        append_images=quadros[1:], duration=155, loop=0,
                        optimize=True, disposal=2)

def wav(nome, freq, samples):
    destino=ASSETS/'sons'/f'{nome}.wav'
    with wave.open(str(destino),'wb') as arq:
        arq.setnchannels(1); arq.setsampwidth(2); arq.setframerate(freq)
        # blocos para reduzir pressão de memória
        for inicio in range(0,len(samples),4096):
            pedaco=samples[inicio:inicio+4096]
            arq.writeframes(struct.pack('<'+'h'*len(pedaco), *pedaco))

def envoltoria(t,d):
    a=min(1,t/0.012)
    r=min(1,max(0,(d-t)/0.085))
    return a*r

def criar_efeito(nome, notas, duracao=.25, vol=.25):
    freq=22050
    amostras=[]
    for n in range(int(duracao*freq)):
        t=n/freq
        sinal=0.0
        for i,(hz,inicio,fim) in enumerate(notas):
            if inicio<=t<fim:
                u=t-inicio
                janela=min(1,u/.012)*min(1,(fim-t)/.08)
                sinal+=math.sin(2*math.pi*hz*u)*janela*(1/(i+1))
        sinal=max(-1,min(1,sinal*vol))
        amostras.append(int(32767*sinal))
    wav(nome,freq,amostras)

def criar_musica():
    # Trilha instrumental sintetizada original: flauta suave + água + textura de floresta.
    # Não imita ou reproduz composição protegida de terceiros.
    freq=22050; tempo=12.0
    total=int(freq*tempo)
    rng=random.Random(11208)
    notas=[196,220,261.63,293.66,329.63,293.66,261.63,220]
    dados=[]
    low=0.0
    for n in range(total):
        t=n/freq
        beat=(t*0.8)%8
        nota=int(beat)%8
        fase=(t*0.8)%1
        m=notas[nota]
        env=0.5+0.5*math.sin(math.pi*min(1, fase))
        flauta=(0.57*math.sin(2*math.pi*m*t) + .16*math.sin(2*math.pi*m*2*t))*env
        pad=.12*math.sin(2*math.pi*98*t)+.07*math.sin(2*math.pi*146.83*t)
        # água: ruído filtrado, a um volume muito baixo
        low=.985*low+.015*rng.uniform(-1,1)
        agua=.045*low
        fade=min(1.0,t/.7,(tempo-t)/.7)
        sample=int(32767*max(-.75,min(.75,(flauta*.09+pad*.22+agua)*max(0,fade))))
        dados.append(sample)
    wav('floresta_ambiente',freq,dados)

if __name__=='__main__':
    criar_gifs()
    criar_efeito('clique',[(520,0,.07),(700,.045,.13)],.17,.2)
    criar_efeito('acerto',[(523,0,.12),(659,.08,.20),(784,.16,.32)],.34,.28)
    criar_efeito('erro',[(240,0,.14),(180,.1,.31)],.34,.24)
    criar_efeito('vitoria',[(523,0,.14),(659,.13,.29),(784,.25,.42),(1046,.37,.65)],.70,.27)
    criar_musica()
    print('Recursos gerados em',ASSETS)
